#!/bin/bash

#User input for data
read -p "What date are you looking for?(MMDD) " DATE
read -p "What time?(HH:MM:SS am) " TIME

#This command will cat all files in the directory
#It takes that input and searchs for the date and opens that file
#Then it searches for the time within the file and prints only the specific fields

cat ~/Desktop/Dealer_Schedules_0310/${DATE}_Dealer_schedule | grep -i "$TIME" | awk -F" " '{print $1,$2,$5,$6}'



