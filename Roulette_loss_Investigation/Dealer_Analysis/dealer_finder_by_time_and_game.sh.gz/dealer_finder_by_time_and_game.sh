
#!/bin/bash

read -p 'What date are you looking for? ' DATE
read -p 'What time are you looking for? ' TIME
read -p 'What game are you looking for? ' GAME

cat ~/Desktop/Dealer_Schedules_0310/${DATE}_Dealer_schedule | grep -i "$TIME" RESULT

if [$GAME == blackjack]
then
   $RESULT awk -F" " '{print $1, $2, $3, $4}'
fi
